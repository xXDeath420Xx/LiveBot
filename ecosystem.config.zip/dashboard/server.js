
const express = require('express');
const session = require('express-session');
const passport = require('passport');
require('./passport-setup');
const path = require('path');
const fs = require('fs');
const db = require('../utils/db');
const cache = require('../utils/cache');
const apiChecks = require('../utils/api_checks.js');
const multer = require('multer');
const { PermissionsBitField, ChannelType, EmbedBuilder } = require('discord.js');
const Papa = require('papaparse');
const { syncTwitchTeam } = require('../core/team-sync');
const logger = require('../utils/logger');
const { invalidateCommandCache } = require('../core/custom-command-handler');
const { createBackup, restoreBackup, deleteBackup } = require('../core/backup-manager');
const { endGiveaway } = require('../core/giveaway-manager');
const { endPoll } = require('../core/poll-manager');

// Setup multer for file uploads
const upload = multer({ dest: 'uploads/' });

async function getManagePageData(guildId, botGuild) {
    logger.info(`[DIAGNOSTIC] getManagePageData is executing for guild ${guildId}.`);

    try {
        // This block is now more resilient and won't crash on undefined values.
        const results = await Promise.all([
            db.execute(`SELECT sub.*, s.platform, s.username, s.discord_user_id, s.streamer_id, s.platform_user_id, cs.channel_id as announcement_channel_override FROM subscriptions sub JOIN streamers s ON sub.streamer_id = s.streamer_id LEFT JOIN channel_settings cs ON sub.announcement_channel_id = cs.channel_id AND sub.guild_id = cs.guild_id WHERE sub.guild_id = ? ORDER BY s.username, sub.announcement_channel_id`, [guildId]).catch(e => { logger.error('Failed to get subscriptions', e); return [[]]; }),
            db.execute('SELECT * FROM guilds WHERE guild_id = ?', [guildId]).catch(e => { logger.error('Failed to get guilds', e); return [[]]; }),
            db.execute('SELECT * FROM channel_settings WHERE guild_id = ?', [guildId]).catch(e => { logger.error('Failed to get channel_settings', e); return [[]]; }),
            (botGuild && botGuild.roles ? botGuild.roles.fetch().catch(e => { logger.error('Failed to fetch roles', e); return new Map(); }) : Promise.resolve(new Map())),
            (botGuild && botGuild.channels ? botGuild.channels.fetch().catch(e => { logger.error('Failed to fetch channels', e); return new Map(); }) : Promise.resolve(new Map())),
            db.execute('SELECT * FROM twitch_teams WHERE guild_id = ?', [guildId]).catch(e => { logger.error('Failed to get twitch_teams', e); return [[]]; }),
            db.execute('SELECT * FROM automod_rules WHERE guild_id = ? ORDER BY id', [guildId]).catch(e => { logger.error('Failed to get automod_rules', e); return [[]]; }),
            db.execute('SELECT * FROM automod_heat_config WHERE guild_id = ?', [guildId]).catch(e => { logger.error('Failed to get automod_heat_config', e); return [[]]; }),
            db.execute('SELECT * FROM antinuke_config WHERE guild_id = ?', [guildId]).catch(e => { logger.error('Failed to get antinuke_config', e); return [[]]; }),
            db.execute('SELECT id, snapshot_name, created_at FROM server_backups WHERE guild_id = ? ORDER BY created_at DESC', [guildId]).catch(e => { logger.error('Failed to get server_backups', e); return [[]]; }),
            db.execute('SELECT * FROM join_gate_config WHERE guild_id = ?', [guildId]).catch(e => { logger.error('Failed to get join_gate_config', e); return [[]]; }),
            db.execute('SELECT * FROM welcome_settings WHERE guild_id = ?', [guildId]).catch(e => { logger.error('Failed to get welcome_settings', e); return [[]]; }),
            db.execute('SELECT * FROM custom_commands WHERE guild_id = ?', [guildId]).catch(e => { logger.error('Failed to get custom_commands', e); return [[]]; }),
            db.execute('SELECT * FROM ticket_config WHERE guild_id = ?', [guildId]).catch(e => { logger.error('Failed to get ticket_config', e); return [[]]; }),
            db.execute('SELECT * FROM auto_publisher_config WHERE guild_id = ?', [guildId]).catch(e => { logger.error('Failed to get auto_publisher_config', e); return [[]]; }),
            db.execute('SELECT * FROM autoroles_config WHERE guild_id = ?', [guildId]).catch(e => { logger.error('Failed to get autoroles_config', e); return [[]]; }),
            db.execute('SELECT * FROM log_config WHERE guild_id = ?', [guildId]).catch(e => { logger.error('Failed to get log_config', e); return [[]]; }),
            db.execute('SELECT * FROM reddit_feeds WHERE guild_id = ?', [guildId]).catch(e => { logger.error('Failed to get reddit_feeds', e); return [[]]; }),
            db.execute('SELECT * FROM youtube_feeds WHERE guild_id = ?', [guildId]).catch(e => { logger.error('Failed to get youtube_feeds', e); return [[]]; }),
            db.execute('SELECT * FROM twitter_feeds WHERE guild_id = ?', [guildId]).catch(e => { logger.error('Failed to get twitter_feeds', e); return [[]]; }),
            db.execute('SELECT * FROM moderation_config WHERE guild_id = ?', [guildId]).catch(e => { logger.error('Failed to get moderation_config', e); return [[]]; }),
            db.execute('SELECT * FROM infractions WHERE guild_id = ? ORDER BY created_at DESC LIMIT 10', [guildId]).catch(e => { logger.error('Failed to get infractions', e); return [[]]; }),
            db.execute('SELECT * FROM escalation_rules WHERE guild_id = ? ORDER BY infraction_count ASC', [guildId]).catch(e => { logger.error('Failed to get escalation_rules', e); return [[]]; }),
            db.execute('SELECT * FROM role_rewards WHERE guild_id = ? ORDER BY level ASC', [guildId]).catch(e => { logger.error('Failed to get role_rewards', e); return [[]]; }),
            db.execute('SELECT * FROM temp_channel_config WHERE guild_id = ?', [guildId]).catch(e => { logger.error('Failed to get temp_channel_config', e); return [[]]; }),
            db.execute('SELECT * FROM server_stats WHERE guild_id = ?', [guildId]).catch(e => { logger.error('Failed to get server_stats', e); return [[]]; }),
            db.execute('SELECT * FROM anti_raid_config WHERE guild_id = ?', [guildId]).catch(e => { logger.error('Failed to get anti_raid_config', e); return [[]]; }),
            db.execute(`SELECT id, tag_name, tag_content, creator_id FROM tags WHERE guild_id = ? ORDER BY tag_name ASC`, [guildId]).catch(e => { logger.error('Failed to get tags', e); return [[]]; }),
            db.execute('SELECT * FROM starboard_config WHERE guild_id = ?', [guildId]).catch(e => { logger.error('Failed to get starboard_config', e); return [[]]; }),
            db.execute('SELECT * FROM reaction_role_panels WHERE guild_id = ?', [guildId]).catch(e => { logger.error('Failed to get reaction_role_panels', e); return [[]]; }),
            db.execute('SELECT * FROM action_logs WHERE guild_id = ? ORDER BY timestamp DESC LIMIT 50', [guildId]).catch(e => { logger.error('Failed to get action_logs', e); return [[]]; }),
            db.execute('SELECT * FROM giveaways WHERE guild_id = ? ORDER BY ends_at DESC', [guildId]).catch(e => { logger.error('Failed to get giveaways', e); return [[]]; }),
            db.execute('SELECT * FROM polls WHERE guild_id = ? ORDER BY ends_at DESC', [guildId]).catch(e => { logger.error('Failed to get polls', e); return [[]]; }),
            db.execute('SELECT * FROM music_config WHERE guild_id = ?', [guildId]).catch(e => { logger.error('Failed to get music_config', e); return [[]]; }),
            db.execute('SELECT * FROM twitch_schedule_sync_config WHERE guild_id = ?', [guildId]).catch(e => { logger.error('Failed to get twitch_schedule_sync_config', e); return [[]]; }),
            db.execute('SELECT * FROM quarantine_config WHERE guild_id = ?', [guildId]).catch(e => { logger.error('Failed to get quarantine_config', e); return [[]]; }),
            db.execute('SELECT * FROM record_config WHERE guild_id = ?', [guildId]).catch(e => { logger.error('Failed to get record_config', e); return [[]]; })
        ]);

        const [
            [allSubscriptions], [guildSettingsResult], [channelSettingsResult],
            allRolesCollection, allChannelsCollection, [rawTeamSubscriptions],
            [automodRules], [heatConfigResult], [antiNukeConfigResult],
            [backups], [joinGateConfigResult], [welcomeSettingsResult], [customCommands],
            [ticketConfigResult], [autoPublisherConfigResult], [autorolesConfigResult],
            [logConfigResult], [redditFeeds], [youtubeFeeds], [twitterFeeds],
            [moderationConfigResult], [recentInfractions], [escalationRules],
            [roleRewards], [tempChannelConfigResult], [serverStats],
            [antiRaidConfigResult], [tags], [starboardConfigResult],
            [reactionRolePanels], [actionLogs], [giveaways], [polls], [musicConfigResult], [twitchScheduleSyncs], [quarantineConfigResult], [recordConfigResult]
        ] = results;

        for (const panel of reactionRolePanels) {
            const [mappings] = await db.execute('SELECT * FROM reaction_role_mappings WHERE panel_id = ?', [panel.id]);
            panel.mappings = mappings || [];
        }

        const consolidatedStreamers = {};
        allSubscriptions.forEach(sub => {
            const key = sub.discord_user_id || sub.username.toLowerCase();
            if (!consolidatedStreamers[key]) {
                consolidatedStreamers[key] = { id: sub.streamer_id, name: sub.username, discord_user_id: sub.discord_user_id, platforms: [], subscriptions: [] };
            }
            consolidatedStreamers[key].subscriptions.push(sub);
            if (!consolidatedStreamers[key].platforms.some(p => p.platform === sub.platform)) {
                consolidatedStreamers[key].platforms.push({ platform: sub.platform, username: sub.username, profile_image_url: sub.profile_image_url });
            }
        });

        const teamSubscriptions = rawTeamSubscriptions.map(t => {
            const role = allRolesCollection.get(t.live_role_id);
            const channel = allChannelsCollection.get(t.announcement_channel_id);
            return { ...t, live_role_name: role ? role.name : 'Not Set', announcement_channel_name: channel ? channel.name : 'Not Set' };
        });

        const heatConfig = heatConfigResult[0];
        const antiNukeConfig = antiNukeConfigResult[0];
        const musicConfig = musicConfigResult[0];
        const quarantineConfig = quarantineConfigResult[0];
        const recordConfig = recordConfigResult[0];

        const dataToReturn = {
            totalSubscriptions: allSubscriptions.length,
            consolidatedStreamers: Object.values(consolidatedStreamers),
            settings: guildSettingsResult[0] || {},
            channelSettings: channelSettingsResult,
            roles: Array.from(allRolesCollection.values()).filter(r => !r.managed && r.name !== '@everyone').map(r => ({ id: r.id, name: r.name })).sort((a, b) => a.name.localeCompare(b.name)),
            channels: Array.from(allChannelsCollection.values()).filter(c => c.type === 0 || c.type === 5).map(c => ({ id: c.id, name: c.name })).sort((a, b) => a.name.localeCompare(b.name)),
            categories: Array.from(allChannelsCollection.values()).filter(c => c.type === 4).map(c => ({ id: c.id, name: c.name })).sort((a, b) => a.name.localeCompare(b.name)),
            voiceChannels: Array.from(allChannelsCollection.values()).filter(c => c.type === 2).map(c => ({ id: c.id, name: c.name })).sort((a, b) => a.name.localeCompare(b.name)),
            teamSubscriptions,
            automodRules,
            heatConfig: heatConfig ? { ...heatConfig, heat_values: JSON.parse(heatConfig.heat_values || '{}'), action_thresholds: JSON.parse(heatConfig.action_thresholds || '[]') } : null,
            antiNukeConfig: antiNukeConfig ? { ...antiNukeConfig, action_thresholds: JSON.parse(antiNukeConfig.action_thresholds || '{}')} : null,
            backups,
            joinGateConfig: joinGateConfigResult[0] || null,
            welcomeSettings: welcomeSettingsResult[0] || null,
            customCommands,
            ticketConfig: ticketConfigResult[0] || null,
            autoPublisherConfig: autoPublisherConfigResult[0] || null,
            autorolesConfig: autorolesConfigResult[0] || null,
            logConfig: logConfigResult[0] || null,
            redditFeeds: redditFeeds || [],
            youtubeFeeds: youtubeFeeds || [],
            twitterFeeds: twitterFeeds || [],
            moderationConfig: moderationConfigResult[0] || null,
            recentInfractions: recentInfractions || [],
            escalationRules: escalationRules || [],
            roleRewards: roleRewards || [],
            tempChannelConfig: tempChannelConfigResult[0] || null,
            serverStats: serverStats || [],
            antiRaidConfig: antiRaidConfigResult[0] || null,
            tags: tags || [],
            starboardConfig: starboardConfigResult[0] || null,
            reactionRolePanels: reactionRolePanels || [],
            actionLogs: actionLogs || [],
            giveaways: giveaways || [],
            polls: polls || [],
            musicConfig: musicConfig ? { ...musicConfig, text_channel_ids: JSON.parse(musicConfig.text_channel_ids || '[]'), voice_channel_ids: JSON.parse(musicConfig.voice_channel_ids || '[]') } : null,
            twitchScheduleSyncs: twitchScheduleSyncs || [],
            quarantineConfig: quarantineConfig || null,
            recordConfig: recordConfig ? { ...recordConfig, allowed_role_ids: JSON.parse(recordConfig.allowed_role_ids || '[]') } : null
        };
        logger.info(`[DIAGNOSTIC] Returning data.`);
        return dataToReturn;
    } catch (error) {
        logger.error(`[CRITICAL] Error in getManagePageData for guild ${guildId}:`, error);
        throw error;
    }
}


function start(botClient) {
    let client = botClient;
    const app = express();
    const port = process.env.DASHBOARD_PORT || 3000;

    app.use(express.static(path.join(__dirname, 'public')));
    app.use(session({ secret: process.env.SESSION_SECRET || 'keyboard cat', resave: false, saveUninitialized: false }));
    app.use(passport.initialize());
    app.use(passport.session());
    app.use(express.json());
    app.use(express.urlencoded({ extended: true }));
    app.set('view engine', 'ejs');
    app.set('views', path.join(__dirname, 'views'));

    const checkAuth = (req, res, next) => req.isAuthenticated() ? next() : res.redirect('/login');
    const checkGuildAdmin = async (req, res, next) => {
        if (!req.user || !req.user.guilds) return res.redirect('/login');
        const guild = req.user.guilds.find(g => g.id === req.params.guildId);
        if (guild && new PermissionsBitField(BigInt(guild.permissions)).has(PermissionsBitField.Flags.ManageGuild) && client.guilds.cache.has(req.params.guildId)) {
            req.guildObject = await client.guilds.fetch(req.params.guildId);
            return next();
        }
        res.status(403).render('error', { user: req.user, error: 'You do not have permissions for this server or the bot is not in it.'});
    };

    app.get('/', (req, res) => {
        if (req.isAuthenticated()) {
            return res.redirect('/servers');
        }
        res.render('index', {
            user: null,
            client_id: process.env.DASHBOARD_CLIENT_ID
        });
    });
    app.get('/login', passport.authenticate('discord', { scope: ['identify', 'guilds'] }));
    app.get('/auth/discord/callback', passport.authenticate('discord', { failureRedirect: '/' }), (req, res) => res.redirect('/servers'));
    app.get('/logout', (req, res, next) => { req.logout(err => { if (err) return next(err); res.redirect('/'); }); });

    app.get('/servers', checkAuth, (req, res) => {
        const manageableGuilds = req.user.guilds.filter(g => new PermissionsBitField(BigInt(g.permissions)).has(PermissionsBitField.Flags.ManageGuild) && client.guilds.cache.has(g.id));
        res.render('servers', { user: req.user, guilds: manageableGuilds });
    });

    app.get('/manage/:guildId', checkAuth, checkGuildAdmin, async (req, res) => {
        try {
            const data = await getManagePageData(req.params.guildId, req.guildObject);
            res.render('manage', {
                user: req.user,
                guild: req.guildObject,
                ...data,
                userPreferences: {} // Adding the missing userPreferences object
            });
        } catch (error) {
            logger.error(`[CRITICAL] Error in /manage/:guildId route:`, error);
            res.status(500).render('error', { user: req.user, error: 'Critical error loading server data.' });
        }
    });

    app.get('/api/guild-channel-list/:guildId', checkAuth, checkGuildAdmin, async (req, res) => {
        try {
            const channels = await req.guildObject.channels.fetch();
            const textChannels = channels.filter(c => c.type === ChannelType.GuildText || c.type === ChannelType.GuildAnnouncement);
            res.json(textChannels.map(c => ({ id: c.id, name: c.name })));
        } catch (error) {
            logger.error(`Error fetching channel list for guild ${req.params.guildId}:`, error);
            res.status(500).json({ error: 'Failed to fetch channel list.' });
        }
    });

    app.post('/manage/:guildId/update-starboard', checkAuth, checkGuildAdmin, async (req, res) => {
        const { channel_id, star_threshold } = req.body;

        if (!channel_id) {
            await db.execute('DELETE FROM starboard_config WHERE guild_id = ?', [req.params.guildId]);
        } else {
            await db.execute(
                'INSERT INTO starboard_config (guild_id, channel_id, star_threshold) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE channel_id = VALUES(channel_id), star_threshold = VALUES(star_threshold)',
                [req.params.guildId, channel_id, star_threshold || 3]
            );
        }
        res.redirect(`/manage/${req.params.guildId}#starboard-tab`);
    });

    app.post('/manage/:guildId/update-tickets', checkAuth, checkGuildAdmin, async (req, res) => {
        const { panel_channel_id, ticket_category_id, support_role_id } = req.body;
        const guildId = req.params.guildId;

        await db.execute(
            `INSERT INTO ticket_config (guild_id, panel_channel_id, ticket_category_id, support_role_id)
             VALUES (?, ?, ?, ?)
             ON DUPLICATE KEY UPDATE
                                  panel_channel_id = VALUES(panel_channel_id),
                                  ticket_category_id = VALUES(ticket_category_id),
                                  support_role_id = VALUES(support_role_id)`,
            [guildId, panel_channel_id || null, ticket_category_id || null, support_role_id || null]
        );

        res.redirect(`/manage/${guildId}#tickets-tab`);
    });

    app.post('/manage/:guildId/update-antiraid', checkAuth, checkGuildAdmin, async (req, res) => {
        const { join_limit, time_period_seconds, action, is_enabled } = req.body;
        await db.execute(
            'INSERT INTO anti_raid_config (guild_id, join_limit, time_period_seconds, action, is_enabled) VALUES (?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE join_limit = VALUES(join_limit), time_period_seconds = VALUES(time_period_seconds), action = VALUES(action), is_enabled = VALUES(is_enabled)',
            [req.params.guildId, join_limit, time_period_seconds, action, is_enabled === 'on' ? 1 : 0]
        );
        res.redirect(`/manage/${req.params.guildId}#security-tab`);
    });

    app.post('/manage/:guildId/update-security', checkAuth, checkGuildAdmin, async (req, res) => {
        const {
            is_enabled, action, action_duration_minutes, min_account_age_days, block_default_avatar,
            verification_enabled, verification_role_id
        } = req.body;
        const guildId = req.params.guildId;

        await db.execute(
            `INSERT INTO join_gate_config (guild_id, is_enabled, action, action_duration_minutes, min_account_age_days, block_default_avatar, verification_enabled, verification_role_id)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?)
             ON DUPLICATE KEY UPDATE
                                  is_enabled = VALUES(is_enabled), action = VALUES(action), action_duration_minutes = VALUES(action_duration_minutes),
                                  min_account_age_days = VALUES(min_account_age_days), block_default_avatar = VALUES(block_default_avatar),
                                  verification_enabled = VALUES(verification_enabled), verification_role_id = VALUES(verification_role_id)`,
            [guildId, is_enabled === 'on' ? 1 : 0, action, action_duration_minutes || null, min_account_age_days || null, block_default_avatar === 'on' ? 1 : 0, verification_enabled === 'on' ? 1 : 0, verification_role_id || null]
        );

        res.redirect(`/manage/${req.params.guildId}#security-tab`);
    });

    app.post('/manage/:guildId/update-welcome', checkAuth, checkGuildAdmin, async (req, res) => {
        const {
            channel_id, message, card_enabled, card_background_url,
            card_title_text, card_subtitle_text, card_title_color,
            card_username_color, card_subtitle_color,
            goodbye_enabled, goodbye_channel_id, goodbye_message
        } = req.body;

        await db.execute(
            `INSERT INTO welcome_settings (guild_id, channel_id, message, card_enabled, card_background_url, card_title_text, card_subtitle_text, card_title_color, card_username_color, card_subtitle_color, goodbye_enabled, goodbye_channel_id, goodbye_message)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
             ON DUPLICATE KEY UPDATE
                                  channel_id=VALUES(channel_id), message=VALUES(message), card_enabled=VALUES(card_enabled),
                                  card_background_url=VALUES(card_background_url), card_title_text=VALUES(card_title_text),
                                  card_subtitle_text=VALUES(card_subtitle_text), card_title_color=VALUES(card_title_color),
                                  card_username_color=VALUES(card_username_color), card_subtitle_color=VALUES(card_subtitle_color),
                                  goodbye_enabled=VALUES(goodbye_enabled), goodbye_channel_id=VALUES(goodbye_channel_id), goodbye_message=VALUES(goodbye_message)`,
            [
                req.params.guildId, channel_id || null, message, card_enabled === 'on' ? 1 : 0,
                card_background_url, card_title_text, card_subtitle_text, card_title_color,
                card_username_color, card_subtitle_color,
                goodbye_enabled === 'on' ? 1 : 0, goodbye_channel_id || null, goodbye_message
            ]
        );
        res.redirect(`/manage/${req.params.guildId}#welcome-tab`);
    });

    app.post('/manage/:guildId/update-autopublisher', checkAuth, checkGuildAdmin, async (req, res) => {
        const { is_enabled } = req.body;
        await db.execute(
            'INSERT INTO auto_publisher_config (guild_id, is_enabled) VALUES (?, ?) ON DUPLICATE KEY UPDATE is_enabled = VALUES(is_enabled)',
            [req.params.guildId, is_enabled === 'on' ? 1 : 0]
        );
        res.redirect(`/manage/${req.params.guildId}#utilities-tab`);
    });

    // New AFK Status Update Route
    app.post('/manage/:guildId/update-afk-status', checkAuth, checkGuildAdmin, async (req, res) => {
        const { afk_enabled } = req.body;
        await db.execute(
            `UPDATE guilds SET afk_enabled = ? WHERE guild_id = ?`,
            [afk_enabled === 'on' ? 1 : 0, req.params.guildId]
        );
        res.redirect(`/manage/${req.params.guildId}#utilities-tab`);
    });

    app.post('/manage/:guildId/update-autoroles', checkAuth, checkGuildAdmin, async (req, res) => {
        const { is_enabled, roles_to_assign } = req.body;
        const roles = roles_to_assign ? (Array.isArray(roles_to_assign) ? roles_to_assign : [roles_to_assign]) : [];

        await db.execute(
            'INSERT INTO autoroles_config (guild_id, is_enabled, roles_to_assign) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE is_enabled = VALUES(is_enabled), roles_to_assign = VALUES(roles_to_assign)',
            [req.params.guildId, is_enabled === 'on' ? 1 : 0, JSON.stringify(roles)]
        );
        res.redirect(`/manage/${req.params.guildId}#utilities-tab`);
    });

    app.post('/manage/:guildId/update-stickyroles', checkAuth, checkGuildAdmin, async (req, res) => {
        const { sticky_roles_enabled } = req.body;
        await db.execute(
            `UPDATE guilds SET sticky_roles_enabled = ? WHERE guild_id = ?`,
            [sticky_roles_enabled === 'on' ? 1 : 0, req.params.guildId]
        );
        res.redirect(`/manage/${req.params.guildId}#utilities-tab`);
    });

    app.post('/manage/:guildId/update-logging', checkAuth, checkGuildAdmin, async (req, res) => {
        const { log_channel_id, enabled_logs } = req.body;
        const logs = enabled_logs ? (Array.isArray(enabled_logs) ? enabled_logs : [enabled_logs]) : [];

        await db.execute(
            'INSERT INTO log_config (guild_id, log_channel_id, enabled_logs) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE log_channel_id = VALUES(log_channel_id), enabled_logs = VALUES(enabled_logs)',
            [req.params.guildId, log_channel_id || null, JSON.stringify(logs)]
        );
        res.redirect(`/manage/${req.params.guildId}#logging-tab`);
    });

    app.post('/manage/:guildId/add-reddit-feed', checkAuth, checkGuildAdmin, async (req, res) => {
        const { subreddit, channel_id } = req.body;
        try {
            await db.execute('INSERT INTO reddit_feeds (guild_id, subreddit, channel_id) VALUES (?, ?, ?)', [req.params.guildId, subreddit.toLowerCase(), channel_id]);
        } catch (e) {
            // Ignore duplicate entry errors
        }
        res.redirect(`/manage/${req.params.guildId}#feeds-tab`);
    });

    app.post('/manage/:guildId/remove-reddit-feed', checkAuth, checkGuildAdmin, async (req, res) => {
        const { feedId } = req.body;
        await db.execute('DELETE FROM reddit_feeds WHERE id = ? AND guild_id = ?', [feedId, req.params.guildId]);
        res.redirect(`/manage/${req.params.guildId}#feeds-tab`);
    });

    app.post('/manage/:guildId/add-youtube-feed', checkAuth, checkGuildAdmin, async (req, res) => {
        const { youtube_channel_id, discord_channel_id } = req.body;
        if (youtube_channel_id.startsWith('UC')) {
            try {
                await db.execute('INSERT INTO youtube_feeds (guild_id, youtube_channel_id, discord_channel_id) VALUES (?, ?, ?)', [req.params.guildId, youtube_channel_id, discord_channel_id]);
            } catch (e) {}
        }
        res.redirect(`/manage/${req.params.guildId}#feeds-tab`);
    });

    app.post('/manage/:guildId/remove-youtube-feed', checkAuth, checkGuildAdmin, async (req, res) => {
        const { feedId } = req.body;
        await db.execute('DELETE FROM youtube_feeds WHERE id = ? AND guild_id = ?', [feedId, req.params.guildId]);
        res.redirect(`/manage/${req.params.guildId}#feeds-tab`);
    });

    app.post('/manage/:guildId/add-twitter-feed', checkAuth, checkGuildAdmin, async (req, res) => {
        const { twitter_username, channel_id } = req.body;
        try {
            await db.execute('INSERT INTO twitter_feeds (guild_id, twitter_username, channel_id) VALUES (?, ?, ?)', [req.params.guildId, twitter_username.toLowerCase(), channel_id]);
        } catch (e) {}
        res.redirect(`/manage/${req.params.guildId}#feeds-tab`);
    });

    app.post('/manage/:guildId/remove-twitter-feed', checkAuth, checkGuildAdmin, async (req, res) => {
        const { feedId } = req.body;
        await db.execute('DELETE FROM twitter_feeds WHERE id = ? AND guild_id = ?', [feedId, req.params.guildId]);
        res.redirect(`/manage/${req.params.guildId}#feeds-tab`);
    });

    app.post('/manage/:guildId/update-moderation', checkAuth, checkGuildAdmin, async (req, res) => {
        const { mod_log_channel_id, muted_role_id } = req.body;
        await db.execute(
            'INSERT INTO moderation_config (guild_id, mod_log_channel_id, muted_role_id) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE mod_log_channel_id = VALUES(mod_log_channel_id), muted_role_id = VALUES(muted_role_id)',
            [req.params.guildId, mod_log_channel_id || null, muted_role_id || null]
        );
        res.redirect(`/manage/${req.params.guildId}#moderation-tab`);
    });

    app.post('/manage/:guildId/add-escalation-rule', checkAuth, checkGuildAdmin, async (req, res) => {
        const { infraction_count, time_period_hours, action, action_duration_minutes } = req.body;
        await db.execute(
            'INSERT INTO escalation_rules (guild_id, infraction_count, time_period_hours, action, action_duration_minutes) VALUES (?, ?, ?, ?, ?)',
            [req.params.guildId, infraction_count, time_period_hours, action, action === 'mute' ? action_duration_minutes : null]
        );
        res.redirect(`/manage/${req.params.guildId}#moderation-tab`);
    });

    app.post('/manage/:guildId/remove-escalation-rule', checkAuth, checkGuildAdmin, async (req, res) => {
        const { ruleId } = req.body;
        await db.execute('DELETE FROM escalation_rules WHERE id = ? AND guild_id = ?', [ruleId, req.params.guildId]);
        res.redirect(`/manage/${req.params.guildId}#moderation-tab`);
    });

    // New AutoMod Heat System Update Route
    app.post('/manage/:guildId/update-automod-heat', checkAuth, checkGuildAdmin, async (req, res) => {
        const { heat_threshold, heat_decay_rate, action, action_duration_minutes, is_enabled } = req.body;
        await db.execute(
            `INSERT INTO automod_heat_config (guild_id, heat_threshold, heat_decay_rate, action, action_duration_minutes, is_enabled)
             VALUES (?, ?, ?, ?, ?, ?)
             ON DUPLICATE KEY UPDATE
                                  heat_threshold = VALUES(heat_threshold),
                                  heat_decay_rate = VALUES(heat_decay_rate),
                                  action = VALUES(action),
                                  action_duration_minutes = VALUES(action_duration_minutes),
                                  is_enabled = VALUES(is_enabled)`,
            [req.params.guildId, heat_threshold, heat_decay_rate, action, action === 'mute' ? action_duration_minutes : null, is_enabled === 'on' ? 1 : 0]
        );
        res.redirect(`/manage/${req.params.guildId}#automod-tab`);
    });

    // New Anti-Nuke Update Route
    app.post('/manage/:guildId/update-antinuke', checkAuth, checkGuildAdmin, async (req, res) => {
        const { is_enabled, action, channel_threshold, role_threshold, ban_kick_threshold } = req.body;
        await db.execute(
            `INSERT INTO antinuke_config (guild_id, is_enabled, action, channel_threshold, role_threshold, ban_kick_threshold)
             VALUES (?, ?, ?, ?, ?, ?)
             ON DUPLICATE KEY UPDATE
                                  is_enabled = VALUES(is_enabled),
                                  action = VALUES(action),
                                  channel_threshold = VALUES(channel_threshold),
                                  role_threshold = VALUES(role_threshold),
                                  ban_kick_threshold = VALUES(ban_kick_threshold)`,
            [req.params.guildId, is_enabled === 'on' ? 1 : 0, action, channel_threshold, role_threshold, ban_kick_threshold]
        );
        res.redirect(`/manage/${req.params.guildId}#security-tab`);
    });

    // New Create Backup Route
    app.post('/manage/:guildId/create-backup', checkAuth, checkGuildAdmin, async (req, res) => {
        const { snapshot_name } = req.body;
        try {
            await createBackup(req.params.guildId, snapshot_name, client);
            res.redirect(`/manage/${req.params.guildId}#backups-tab`);
        } catch (error) {
            logger.error(`Error creating backup for guild ${req.params.guildId}:`, error);
            res.status(500).render('error', { user: req.user, error: 'Failed to create backup.' });
        }
    });

    // New Restore Backup Route
    app.post('/manage/:guildId/restore-backup', checkAuth, checkGuildAdmin, async (req, res) => {
        const { backupId } = req.body;
        try {
            await restoreBackup(backupId, client);
            res.redirect(`/manage/${req.params.guildId}#backups-tab`);
        } catch (error) {
            logger.error(`Error restoring backup ${backupId} for guild ${req.params.guildId}:`, error);
            res.status(500).render('error', { user: req.user, error: 'Failed to restore backup.' });
        }
    });

    // New Delete Backup Route
    app.post('/manage/:guildId/delete-backup', checkAuth, checkGuildAdmin, async (req, res) => {
        const { backupId } = req.body;
        try {
            await deleteBackup(backupId);
            res.redirect(`/manage/${req.params.guildId}#backups-tab`);
        } catch (error) {
            logger.error(`Error deleting backup ${backupId} for guild ${req.params.guildId}:`, error);
            res.status(500).render('error', { user: req.user, error: 'Failed to delete backup.' });
        }
    });

    // New Giveaway Routes
    app.post('/manage/:guildId/create-giveaway', checkAuth, checkGuildAdmin, async (req, res) => {
        const { prize, winner_count, duration_minutes, channel_id } = req.body;
        const ends_at = new Date(Date.now() + parseInt(duration_minutes) * 60 * 1000);

        try {
            const guild = client.guilds.cache.get(req.params.guildId);
            const channel = guild.channels.cache.get(channel_id);

            if (!channel) {
                return res.status(400).render('error', { user: req.user, error: 'Invalid channel selected.' });
            }

            const giveawayEmbed = new EmbedBuilder()
                .setTitle(prize)
                .setDescription(`React with 🎉 to enter!\nWinner(s): ${winner_count}\nEnds: <t:${Math.floor(ends_at.getTime() / 1000)}:R>`)
                .setFooter({ text: 'Giveaway' })
                .setTimestamp(ends_at);

            const message = await channel.send({ embeds: [giveawayEmbed] });
            await message.react('🎉');

            await db.execute(
                'INSERT INTO giveaways (guild_id, channel_id, message_id, prize, winner_count, ends_at, is_active) VALUES (?, ?, ?, ?, ?, ?, ?)',
                [req.params.guildId, channel_id, message.id, prize, winner_count, ends_at, 1]
            );
            res.redirect(`/manage/${req.params.guildId}#giveaways-tab`);
        } catch (error) {
            logger.error(`Error creating giveaway for guild ${req.params.guildId}:`, error);
            res.status(500).render('error', { user: req.user, error: 'Failed to create giveaway.' });
        }
    });

    app.post('/manage/:guildId/end-giveaway', checkAuth, checkGuildAdmin, async (req, res) => {
        const { giveawayId } = req.body;
        try {
            const [[giveaway]] = await db.execute('SELECT * FROM giveaways WHERE id = ? AND guild_id = ?', [giveawayId, req.params.guildId]);
            if (giveaway) {
                await endGiveaway(giveaway, false); // Use the endGiveaway function from core
            }
            res.redirect(`/manage/${req.params.guildId}#giveaways-tab`);
        } catch (error) {
            logger.error(`Error ending giveaway ${giveawayId} for guild ${req.params.guildId}:`, error);
            res.status(500).render('error', { user: req.user, error: 'Failed to end giveaway.' });
        }
    });

    app.post('/manage/:guildId/reroll-giveaway', checkAuth, checkGuildAdmin, async (req, res) => {
        const { giveawayId } = req.body;
        try {
            const [[giveaway]] = await db.execute('SELECT * FROM giveaways WHERE id = ? AND guild_id = ?', [giveawayId, req.params.guildId]);
            if (giveaway) {
                await endGiveaway(giveaway, true); // Use the endGiveaway function from core, set isReroll to true
            }
            res.redirect(`/manage/${req.params.guildId}#giveaways-tab`);
        } catch (error) {
            logger.error(`Error rerolling giveaway ${giveawayId} for guild ${req.params.guildId}:`, error);
            res.status(500).render('error', { user: req.user, error: 'Failed to reroll giveaway.' });
        }
    });

    app.post('/manage/:guildId/delete-giveaway', checkAuth, checkGuildAdmin, async (req, res) => {
        const { giveawayId } = req.body;
        try {
            await db.execute('DELETE FROM giveaways WHERE id = ? AND guild_id = ?', [giveawayId, req.params.guildId]);
            res.redirect(`/manage/${req.params.guildId}#giveaways-tab`);
        } catch (error) {
            logger.error(`Error deleting giveaway ${giveawayId} for guild ${req.params.guildId}:`, error);
            res.status(500).render('error', { user: req.user, error: 'Failed to delete giveaway.' });
        }
    });

    // New Poll Routes
    app.post('/manage/:guildId/create-poll', checkAuth, checkGuildAdmin, async (req, res) => {
        const { question, options, duration_minutes, channel_id } = req.body;
        const ends_at = new Date(Date.now() + parseInt(duration_minutes) * 60 * 1000);
        const pollOptions = options.split(',').map(opt => opt.trim());

        if (pollOptions.length < 2 || pollOptions.length > 10) {
            return res.status(400).render('error', { user: req.user, error: 'A poll must have between 2 and 10 options.' });
        }

        try {
            const guild = client.guilds.cache.get(req.params.guildId);
            const channel = guild.channels.cache.get(channel_id);

            if (!channel) {
                return res.status(400).render('error', { user: req.user, error: 'Invalid channel selected.' });
            }

            const numberEmojis = ['1️⃣', '2️⃣', '3️⃣', '4️⃣', '5️⃣', '6️⃣', '7️⃣', '8️⃣', '9️⃣', '🔟'];
            const optionsText = pollOptions.map((option, index) => `${numberEmojis[index]} ${option}`).join('\n');

            const pollEmbed = new EmbedBuilder()
                .setTitle(question)
                .setDescription(`${optionsText}\n\nEnds: <t:${Math.floor(ends_at.getTime() / 1000)}:R>`)
                .setFooter({ text: 'Poll' })
                .setTimestamp(ends_at);

            const message = await channel.send({ embeds: [pollEmbed] });
            for (let i = 0; i < pollOptions.length; i++) {
                await message.react(numberEmojis[i]);
            }

            await db.execute(
                'INSERT INTO polls (guild_id, channel_id, message_id, question, options,