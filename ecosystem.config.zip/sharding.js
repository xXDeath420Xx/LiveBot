// This file is no longer used as sharding has been disabled.
// The bot is now run directly via index.js.
