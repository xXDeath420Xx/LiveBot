const pendingInteractions = new Map();

module.exports = { pendingInteractions };
    