const winston = require('winston');
const path = require('path');

const logPath = path.join(__dirname, '..', 'logs', 'app.log');

const logger = winston.createLogger({
    level: 'info',
    format: winston.format.json(),
    transports: [
        new winston.transports.Console({ format: winston.format.simple() }),
        new winston.transports.File({ filename: logPath, level: 'info' })
    ]
});

module.exports = logger;
    