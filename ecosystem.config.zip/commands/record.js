const { SlashCommandBuilder, PermissionsBitField, EmbedBuilder } = require('discord.js');
const { joinVoiceChannel, createAudioReceiver, EndBehaviorType } = require('@discordjs/voice');
const fs = require('fs');
const prism = require('prism-media');
const db = require('../utils/db');
const logger = require('../utils/logger');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('record')
    .setDescription('Records the audio in a voice channel.'),
  async execute(interaction) {
    await interaction.deferReply({ ephemeral: true });

    const guildId = interaction.guild.id;
    const member = interaction.member;

    // Fetch record configuration from the database
    const [[recordConfig]] = await db.execute('SELECT is_enabled, allowed_role_ids, output_channel_id FROM record_config WHERE guild_id = ?', [guildId]);

    if (!recordConfig || !recordConfig.is_enabled) {
      return interaction.editReply({ content: 'Voice recording is not enabled for this server.' });
    }

    const allowedRoleIds = recordConfig.allowed_role_ids ? JSON.parse(recordConfig.allowed_role_ids) : [];
    const outputChannelId = recordConfig.output_channel_id;

    // Check permissions
    const isAdmin = member.permissions.has(PermissionsBitField.Flags.Administrator);
    const hasAllowedRole = allowedRoleIds.some(roleId => member.roles.cache.has(roleId));

    if (!isAdmin && !hasAllowedRole) {
      return interaction.editReply({ content: 'You do not have permission to use this command.' });
    }

    const voiceChannel = member.voice.channel;
    if (!voiceChannel) {
      return interaction.editReply({ content: 'You must be in a voice channel to use this command.' });
    }

    let outputChannel = null;
    if (outputChannelId) {
        try {
            outputChannel = await interaction.client.channels.fetch(outputChannelId);
        } catch (e) {
            logger.error(`[Record Command] Could not fetch output channel ${outputChannelId} for guild ${guildI