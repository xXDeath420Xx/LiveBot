const { Events } = require('discord.js');
const db = require('../utils/db');

async function handleReactionAdd(reaction, user) {
    if (reaction.partial) {
        try {
            await reaction.fetch();
        } catch (error) {
            console.error('Something went wrong when fetching the message:', error);
            return;
        }
    }

    const [panels] = await db.execute('SELECT * FROM reaction_role_panels WHERE message_id = ?', [reaction.message.id]);
    if (panels.length === 0) return;

    const panel = panels[0];
    const [mappings] = await db.execute('SELECT * FROM reaction_role_mappings WHERE panel_id = ? AND emoji_id = ?', [panel.id, reaction.emoji.id || reaction.emoji.name]);
    if (mappings.length === 0) return;

    const mapping = mappings[0];
    const guild = reaction.message.guild;
    const member = await guild.members.fetch(user.id);
    const role = await guild.roles.fetch(mapping.role_id);

    if (role) {
        if (panel.panel_mode === 'toggle') {
            if (member.roles.cache.has(role.id)) {
                await member.roles.remove(role);
            } else {
                await member.roles.add(role);
            }
        } else { // Default to 'add'
            await member.roles.add(role);
        }
    }
}

async function handleReactionRemove(reaction, user) {
    if (reaction.partial) {
        try {
            await reaction.fetch();
        } catch (error) {
            console.error('Something went wrong when fetching the message:', error);
            return;
        }
    }

    const [panels] = await db.execute('SELECT * FROM reaction_role_panels WHERE message_id = ?', [reaction.message.id]);
    if (panels.length === 0) return;

    const panel = panels[0];
    if (panel.panel_mode !== 'toggle') return; // Only handle remove for toggle mode

    const [mappings] = await db.execute('SELECT * FROM reaction_role_mappings WHERE panel_id = ? AND emoji_id = ?', [panel.id, reaction.emoji.id || reaction.emoji.name]);
    if (mappings.length === 0) return;

    const mapping = mappings[0];
    const guild = reaction.message.guild;
    const member = await guild.members.fetch(user.id);
    const role = await guild.roles.fetch(mapping.role_id);

    if (role && member.roles.cache.has(role.id)) {
        await member.roles.remove(role);
    }
}

module.exports = {
    handleReactionAdd,
    handleReactionRemove,
};