const db = require('../utils/db');
const logger = require('../utils/logger');

async function createBackup(guildId, snapshotName, client) {
    logger.info(`[BackupManager] Creating backup for guild ${guildId} with name: ${snapshotName}`);
    try {
        const [guildSettings] = await db.execute('SELECT * FROM guilds WHERE guild_id = ?', [guildId]);
        const [channelSettings] = await db.execute('SELECT * FROM channel_settings WHERE guild_id = ?', [guildId]);
        const [automodRules] = await db.execute('SELECT * FROM automod_rules WHERE guild_id = ?', [guildId]);
        const [automodHeatConfig] = await db.execute('SELECT * FROM automod_heat_config WHERE guild_id = ?', [guildId]);
        const [antiNukeConfig] = await db.execute('SELECT * FROM antinuke_config WHERE guild_id = ?', [guildId]);
        const [joinGateConfig] = await db.execute('SELECT * FROM join_gate_config WHERE guild_id = ?', [guildId]);
        const [welcomeSettings] = await db.execute('SELECT * FROM welcome_settings WHERE guild_id = ?', [guildId]);
        const [customCommands] = await db.execute('SELECT * FROM custom_commands WHERE guild_id = ?', [guildId]);
        const [ticketConfig] = await db.execute('SELECT * FROM ticket_config WHERE guild_id = ?', [guildId]);
        const [autoPublisherConfig] = await db.execute('SELECT * FROM auto_publisher_config WHERE guild_id = ?', [guildId]);
        const [autorolesConfig] = await db.execute('SELECT * FROM autoroles_config WHERE guild_id = ?', [guildId]);
        const [logConfig] = await db.execute('SELECT * FROM log_config WHERE guild_id = ?', [guildId]);
        const [redditFeeds] = await db.execute('SELECT * FROM reddit_feeds WHERE guild_id = ?', [guildId]);
        const [youtubeFeeds] = await db.execute('SELECT * FROM youtube_feeds WHERE guild_id = ?', [guildId]);
        const [twitterFeeds] = await db.execute('SELECT * FROM twitter_feeds WHERE guild_id = ?', [guildId]);
        const [moderationConfig] = await db.execute('SELECT * FROM moderation_config WHERE guild_id = ?', [guildId]);
        const [escalationRules] = await db.execute('SELECT * FROM escalation_rules WHERE guild_id = ?', [guildId]);
        const [roleRewards] = await db.execute('SELECT * FROM role_rewards WHERE guild_id = ?', [guildId]);
        const [tempChannelConfig] = await db.execute('SELECT * FROM temp_channel_config WHERE guild_id = ?', [guildId]);
        const [antiRaidConfig] = await db.execute('SELECT * FROM anti_raid_config WHERE guild_id = ?', [guildId]);
        const [tags] = await db.execute('SELECT * FROM tags WHERE guild_id = ?', [guildId]);
        const [starboardConfig] = await db.execute('SELECT * FROM starboard_config WHERE guild_id = ?', [guildId]);
        const [reactionRolePanels] = await db.execute('SELECT * FROM reaction_role_panels WHERE guild_id = ?', [guildId]);
        const [reactionRoleMappings] = await db.execute('SELECT rrm.* FROM reaction_role_mappings rrm JOIN reaction_role_panels rrp ON rrm.panel_id = rrp.id WHERE rrp.guild_id = ?', [guildId]);

        const backupData = {
            guildSettings: guildSettings[0] || null,
            channelSettings,
            automodRules,
            automodHeatConfig: automodHeatConfig[0] || null,
            antiNukeConfig: antiNukeConfig[0] || null,
            joinGateConfig: joinGateConfig[0] || null,
            welcomeSettings: welcomeSettings[0] || null,
            customCommands,
            ticketConfig: ticketConfig[0] || null,
            autoPublisherConfig: autoPublisherConfig[0] || null,
            autorolesConfig: autorolesConfig[0] || null,
            logConfig: logConfig[0] || null,
            redditFeeds,
            youtubeFeeds,
            twitterFeeds,
            moderationConfig: moderationConfig[0] || null,
            escalationRules,
            roleRewards,
            tempChannelConfig: tempChannelConfig[0] || null,
            antiRaidConfig: antiRaidConfig[0] || null,
            tags,
            starboardConfig: starboardConfig[0] || null,
            reactionRolePanels,
            reactionRoleMappings
        };

        const [result] = await db.execute(
            'INSERT INTO server_backups (guild_id, snapshot_name, backup_data) VALUES (?, ?, ?)',
            [guildId, snapshotName, JSON.stringify(backupData)]
        );
        logger.info(`[BackupManager] Backup ${result.insertId} created successfully for guild ${guildId}.`);
        return result.insertId;
    } catch (error) {
        logger.error(`[BackupManager] Error creating backup for guild ${guildId}:`, error);
  